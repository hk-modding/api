Hollow Knight Modding API
=========================

This is a simple modding API used mainly for compatibility between mods. It does nothing on its own, but is required for several mods to run.

How To Install
==============

Navigate to your Hollow Knight Game Install folder.

    Steam: C:\Program Files (x86)\Steam\steamapps\common\Hollow Knight\
    GoG:

Copy Everything in this Zip file into the game's folder.  When prompted to Overwrite files, say yes.

How To Uninstall
================

    Steam: Right Click on Hollow Knight->Properties->Local Files->Verify Integrity of Game Files